import pandas as pd
import matplotlib.pyplot as plt

data = {
    "Vehicle_Rent": [500, 600, 700, 800, 900,1000, 1100, 1200, 1300, 1400]
}

df = pd.DataFrame(data)
print(df)

plt.boxplot(df["Vehicle_Rent"])
plt.title("Box Plot of Vehicle Rent")
plt.ylabel("Vehicle Rent")

plt.show()
